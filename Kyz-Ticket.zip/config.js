module.exports = {
    prefix: '!', // préfixe
    token: 'prout', 
    embedColor: '#800080', // violet
};
