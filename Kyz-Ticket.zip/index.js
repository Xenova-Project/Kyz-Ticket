const { 
    Client, 
    GatewayIntentBits, 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionsBitField 
} = require('discord.js');
const config = require('./config.js');
const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers]
});
const roles = {
    owner: '1295006739367985195',// ID du rôle Owner
    staff: '1295006743511830620',// ID du rôle Staff
    abuseManager: '1295006744422125673' // ID du rôle Gestion d'Abus
};
client.once('ready', () => {
    console.log(`Connecté en tant que ${client.user.tag}`);
});
client.on('messageCreate', async message => {
    if (message.author.bot) return;
    if (message.content.startsWith('!ticketset')) {
        const embed = new EmbedBuilder()
            .setColor(0xFFFFFF)
            .setTitle('Tickets Support Kyz')
            .setThumbnail('https://cdn.discordapp.com/attachments/1274092226342813858/1295469230787006505/2dda4bae4c15d9fb24ffe32fbcf93395.jpg')
            .setDescription('Bonjour,\nPour ouvrir un ticket, sélectionnez le type de ticket ci-dessous :');

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('ticket_type')
            .setPlaceholder('Sélectionnez un type de ticket')
            .addOptions([
                {
                    label: 'Ticket Owner 👑', 
                    value: 'owner_ticket',
                    description: 'Fusion ou partenariat',
                },
                {
                    label: 'Staff 👮', 
                    value: 'staff_ticket',
                    description: 'Demander un rank',
                },
                {
                    label: 'Gestion d\'Abus 🚨', 
                    value: 'abuse_ticket',
                    description: 'Rapport d\'abus ou de comportement',
                },
            ]);
        const selectRow = new ActionRowBuilder().addComponents(selectMenu);
        await message.channel.send({ embeds: [embed], components: [selectRow] });
    }
    if (message.content.startsWith('!close')) {
        if (message.channel.name.startsWith('ticket-')) {
            await message.channel.delete(`Ticket fermé par ${message.author.tag}`)
                .catch(err => console.error(`Erreur lors de la fermeture du ticket : ${err}`));
            await message.reply({ content: 'Le ticket a été fermé.', ephemeral: true });
        } else {
            await message.reply({ content: 'Cette commande peut seulement être utilisée dans un salon de ticket.', ephemeral: true });
        }
    }
});
client.on('interactionCreate', async interaction => {
    if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'ticket_type') {
            const selectedValue = interaction.values[0];
            let ticketChannelName;
            let allowedRoles;
            if (selectedValue === 'owner_ticket') {
                ticketChannelName = `ticket-owner-${interaction.user.username}`;
                allowedRoles = [roles.owner]; 
            } else if (selectedValue === 'staff_ticket') {
                ticketChannelName = `ticket-staff-${interaction.user.username}`;
                allowedRoles = [roles.staff]; 
            } else if (selectedValue === 'abuse_ticket') {
                ticketChannelName = `ticket-abuse-${interaction.user.username}`;
                allowedRoles = [roles.abuseManager]; 
            }
            const ticketChannel = await interaction.guild.channels.create({
                name: ticketChannelName,
                type: 0, 
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionsBitField.Flags.ViewChannel], 
                    },
                    {
                        id: interaction.user.id,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                    },
                    ...allowedRoles.map(roleId => ({
                        id: roleId,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                    })),ccéd
                ],
            });
            await ticketChannel.send(`Salut <@${interaction.user.id}> ! Ton ticket a été ouvert avec succès. Les membres de l’équipe <@&${allowedRoles.join('>, <@&')}> te répondront bientôt. Merci de patienter !`);
            const closeButton = new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('Fermer le Ticket')
                .setStyle(ButtonStyle.Danger);

            const buttonRow = new ActionRowBuilder().addComponents(closeButton);
            await ticketChannel.send({ content: 'Cliquez sur le bouton ci-dessous pour fermer ce ticket:', components: [buttonRow] });
            await interaction.reply({ content: `Le ticket a été créé : ${ticketChannel}.`, ephemeral: true });
        }
    }
    if (interaction.isButton()) {
        if (interaction.customId === 'close_ticket') {
            const ticketChannel = interaction.channel;
            await ticketChannel.delete(`Ticket fermé par ${interaction.user.tag}`)
                .catch(err => console.error(`Erreur lors de la fermeture du ticket : ${err}`));
            await interaction.reply({ content: 'Le ticket a été fermé.', ephemeral: true })
                .catch(err => console.error(`Erreur lors de la réponse : ${err}`));
        }
    }
});

client.login(config.token);
